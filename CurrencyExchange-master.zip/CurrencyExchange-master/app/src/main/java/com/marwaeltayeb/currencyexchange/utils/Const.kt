package com.marwaeltayeb.currencyexchange.utils

class Const {
    companion object {
        const val BASE_URL = "https://api.exchangerate.host/"
        const val FROM_CURRENCY = "USD"
        const val TO_CURRENCY = "EUR"
    }
}